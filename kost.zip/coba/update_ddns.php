<?php
header("Location: http://members.tunnel.my.id/ddns/hotspot/eff165727da5330d22b181c3024073cc");
?>